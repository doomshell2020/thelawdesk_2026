<?php
/**
Template Name: Practice 
 */

get_header(); ?>
<style>
.page .site-main{ max-width:100% !important;}
</style>
	<div class="practice_areapg">
    <div id="primary" class="site-content">
		<div id="content" role="main">
		<div class="bnr-img-pg2"><?php $url= wp_get_attachment_url(get_post_thumbnail_id($post->ID));?>
				<!--<img src="<?php //echo $url?>">-->	
                <?php echo the_post_thumbnail('full'); ?>	
                <header class="entry-header">
			<h1 class="entry-title"><?php the_title(); ?></h1>
		</header>
                </div>
        
<div class=" inner_content"><div class="container"><?php $the_query = new WP_Query( 'page_id=6' );
      while ( $the_query->have_posts() ) :	$the_query->the_post();
	  ?>
<div class="entry-content">
<p style="text-align:justify">
	  <?php
	  echo get_the_content(); ?> </p></div> <?php
	  endwhile;
	  wp_reset_postdata();?>
	  <div class="clear"></div>

	  <section id="practice_areservices_sec">
	  	
<div class="container">
	<div class="row no-gutters">
		



 <?php
		$args = array(
    'post_type' => 'practice_area',
    'posts_per_page'=>-1,
    'post_status'=>'publish',
    'orderby'=>'date',
    'order'=>'Desc'
 );

		$client_qry = new WP_Query($args );
		
		
		while ( $client_qry->have_posts()) : $client_qry->the_post();
		?>
			<div class="col-lg-2 col-md-3 col-sm-4 col-6">
			<div class="practice_servbox">
			<?php 	$url=wp_get_attachment_url(get_post_thumbnail_id($post->ID)); ?>
				<a href="<?php the_permalink(); ?>"><?php echo the_post_thumbnail('full');?>
				<h5><?php echo get_the_title(); ?></h5></a>
			</div>
		</div>

		
		
		
		<?php  endwhile;?>

		
	

			

			
			

			
		
	</div>
</div>
	  </section>

	 <?php /*   <div class="prat praticeinner">
		<?php wp_nav_menu( array( 'theme_location' => 'Secondry', 'menu_class' => 'nav-menu', 'menu_id' => 'Secondry-menu' ) ); ?>
        
        </div> */ ?>
        </div></div>
		</div><!-- #content -->
	</div>
    </div><!-- #primary -->

<?php /*<?php get_sidebar(); ?>*/ ?>
<?php get_footer(); ?>
